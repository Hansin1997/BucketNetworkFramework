package Common;

import Database.DatabaseManager;
import Network.SocketPool;

public class Gobal {
	
	public static DatabaseManager db;
	public static SocketPool pool;
	
	public static void setDb(DatabaseManager db) {
		Gobal.db = db;
	}
	
	public static DatabaseManager getDb() {
		return db;
	}
	
	public static void setPool(SocketPool pool) {
		Gobal.pool = pool;
	}
	
	public static SocketPool getPool() {
		return pool;
	}


}
