package Network.BucketObject;

public class TestTable {

	public String a;
	public String b;
	public float c;
	public double d;
	
	public void setA(String a) {
		this.a = a;
	}
	
	public void setB(String b) {
		this.b = b;
	}
	
	public void setC(float c) {
		this.c = c;
	}
	
	public void setD(double d) {
		this.d = d;
	}
	
	public String getA() {
		return a;
	}
	
	public String getB() {
		return b;
	}
	public float getC() {
		return c;
	}
	public double getD() {
		return d;
	}
	
}
