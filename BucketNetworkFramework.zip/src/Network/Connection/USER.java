package Network.Connection;

public class USER {
	
	public String username;
	public String password;
	
	public String nickname;
	public String type;
	
	public void setType(String type) {
		this.type = type;
	}
	
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getType() {
		return type;
	}
	
	public String getNickname() {
		return nickname;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String getUsername() {
		return username;
	}

}
