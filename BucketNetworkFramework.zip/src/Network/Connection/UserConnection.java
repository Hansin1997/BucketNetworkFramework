package Network.Connection;

import java.io.IOException;
import java.net.Socket;

import Common.Tool;
import Network.BucketListener;

public class UserConnection extends Connection{

	public String username;
	private boolean isServer;
	
	public UserConnection(Socket socket, BucketListener messageListener) throws IOException {
		this(socket, messageListener,false);
	}
	
	public UserConnection(Socket socket, BucketListener messageListener,boolean isServer) throws IOException {
		super(socket, messageListener);
		this.isServer = isServer;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getUsername() {
		return username;
	}
	
	@Override
	public void startListen() throws IOException {
		if(isServer)
		{
			socket.setSoTimeout(2000);
			
			if(check(readLine()))
			{
				socket.setSoTimeout(0);
				super.startListen();
			}else{
				socket.close();
			}
		}else{
			super.startListen();
		}

		
		
	}
	
	public void login(USER user) throws IOException
	{
		out.write(new String((Tool.toJson(user) + "\n").getBytes(),getEncoding()).getBytes());
		out.flush();
	}
	
	private boolean check(String str)
	{
		
		username = str;
		return true;
	}

}
